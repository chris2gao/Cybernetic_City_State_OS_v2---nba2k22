import json,zlib
from pathlib import Path
run=Path(__file__).resolve().parent
meta=json.loads((run/'player-state-metadata-01/metadata.json').read_bytes());player=next(t for t in meta if t['name']=='PLAYERDATA')
labels=json.loads((run/'player-state-literal-labels.json').read_bytes());mapped=json.loads((run/'native-type-initializer-map.json').read_bytes())['native_type_candidates'];by_rva={t['type_rva']:t for t in mapped}
names=('Type','IsActive','IsHidden','IsGenerated','IsDraftProspect','WasDrafted','IsHistoric','IsDLeague','IsDLeagueSendDown','GLeagueTeam','College','FreeAgencyType','OffSeasonFreeAgent','OffSeasonFreeAgentExtendedDeadline','IsWaived','IsPlayable','DraftedTeam','DraftedRound','DraftedPick')
rows=[]
for name in names:
    found=[f for f in player['fields'] if f['name_crc']==zlib.crc32(name.encode())]
    if not found:continue
    f=found[0];rows.append({'name':name,'offset':f['offset'],'size':f['size'],'width':f['width'],'bit':f['start_bit'],
        'type_names':labels.get(str(f['words'][1]),[]),'type_rva':f['enum_pointer']-0x140000000 if f['enum_pointer'] else None})
col=next(f for f in player['fields'] if f['name_crc']==zlib.crc32(b'College'))
related=[t for t in mapped if t['name'] in ('COLLEGEDATA','PLAYERDATA_TYPE','GLEAGUE_TEAM_ID','FREE_AGENCY_TYPE','COUNTRY','COUNTRY_ID','COUNTRYDATA') or zlib.crc32(t['name'].encode())==col['words'][1]]
print(json.dumps({'fields':rows,'types':[{k:t[k] for k in ('name','type_rva','constructor_rva')} for t in related]}))
