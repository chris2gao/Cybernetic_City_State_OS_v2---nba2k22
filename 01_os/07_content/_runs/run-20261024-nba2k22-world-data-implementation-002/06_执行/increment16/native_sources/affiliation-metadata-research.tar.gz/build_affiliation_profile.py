import hashlib,json,mmap,re,zlib
from pathlib import Path
run=Path(__file__).resolve().parent;app=Path.cwd()/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype'
meta=json.loads((run/'affiliation-metadata-01/metadata.json').read_bytes())+json.loads((run/'college-region-metadata-01/metadata.json').read_bytes())
entries=json.loads((run/'affiliation-metadata-01/type_entries.json').read_bytes())+json.loads((run/'college-region-metadata-01/type_entries.json').read_bytes())
labels=json.loads((run/'affiliation-literal-labels.json').read_bytes());wanted={v['name_crc'] for t in meta for v in t.get('values',[])}
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as file,mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ) as data:
    for m in re.finditer(rb'(?<=\x00)[A-Za-z_][A-Za-z0-9_:]{0,95}\x00',data):
        raw=m.group()[:-1];crc=zlib.crc32(raw)
        if crc in wanted:labels.setdefault(str(crc),[]);name=raw.decode()
        else:continue
        if name not in labels[str(crc)]:labels[str(crc)].append(name)
by_name={t['name']:t for t in meta};fields={name:{f['name_crc']:f for f in t['fields']} for name,t in by_name.items() if 'fields' in t}
requested={'Type':'native_player_type_raw','IsActive':'is_active_raw','IsHidden':'is_hidden_raw','IsGenerated':'is_generated_raw','IsDraftProspect':'is_draft_prospect_raw','WasDrafted':'was_drafted_raw',
    'IsHistoric':'is_historic_raw','IsDLeague':'is_d_league_raw','IsDLeagueSendDown':'is_d_league_send_down_raw','GLeagueTeam':'g_league_team_raw','FreeAgencyType':'free_agency_type_raw',
    'OffSeasonFreeAgent':'offseason_free_agent_raw','OffSeasonFreeAgentExtendedDeadline':'offseason_free_agent_extended_raw','IsWaived':'is_waived_raw','IsPlayable':'is_playable_raw','DraftedRound':'drafted_round_raw','DraftedPick':'drafted_pick_raw'}
bound={column:{**fields['PLAYERDATA'][zlib.crc32(native.encode())],'native_name':native} for native,column in requested.items()}
college_names={'UnlocalizedName':'native_label','LocalizedName':'localized_name_crc_raw','AppearanceGroup':'appearance_group_raw','RegionId':'region_id_raw','CollegeId':'college_id_raw','IsHighSchool':'is_high_school_raw'}
college={column:{**fields['COLLEGEDATA'][zlib.crc32(native.encode())],'native_name':native} for native,column in college_names.items()}
for entry in entries:
    t=by_name[entry['name']]
    if 'fields' in t:
        sig=sorted((f['name_crc'],f['offset'],f['size'],f['format'],f['words'][5]) for f in t['fields']);entry.update({'expected_size':t['struct_size'],'expected_field_count':len(t['fields']),
            'field_signature_sha256':hashlib.sha256(json.dumps(sig,separators=(',',':')).encode()).hexdigest()})
enums={t['name']:{str(v['value']):{'name_crc':v['name_crc'],'labels':labels.get(str(v['name_crc']),[])} for v in t['values']} for t in meta if 'values' in t}
if any(len(d['labels'])!=1 for values in enums.values() for d in values.values()):raise ValueError('ambiguous native enum literal')
dimension=json.loads((run/'college-region-metadata-01/name-dimension.json').read_bytes());college['native_label']['array_extent']=dimension['elements']
output={'status':'CURRENT_NATIVE_FIELD_SIGNATURES_ENUM_CODES_LITERAL_CRCS_AND_NAME_DIMENSION; MARKET_ELIGIBILITY_AND_COUNTRY_CATEGORY_SEPARATE',
    'module_timestamp':1652287197,'types':entries,'player_fields':bound,'college_fields':college,'enum_labels':enums,
    'college_pointer':fields['PLAYERDATA'][zlib.crc32(b'College')],
    'college_public_ranges':[[0,dimension['elements']],[36,47],[56,60]],
    'college_excluded_configuration_byte':47}
destination=app/'player_affiliation_native_profile.json'
if destination.exists():raise FileExistsError('inspect before replacing native profile')
destination.write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'player_fields':len(bound),'college_name_extent':dimension['elements'],'college_public_ranges':output['college_public_ranges'],
    'region_enum':enums['COLLEGEDATA_REGION'],'signability_status':'NOT_DERIVED_FROM_CLASSIFICATION'}))
