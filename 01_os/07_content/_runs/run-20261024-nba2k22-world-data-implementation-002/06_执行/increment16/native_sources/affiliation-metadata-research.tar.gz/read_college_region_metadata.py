import hashlib,json,sys,zlib
from pathlib import Path
repo=Path.cwd();app=repo/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype';sys.path.insert(0,str(app))
from league_reader import read_native_enum
from live_reader import ReadOnlyGameProcess
from live_world import _json
run=Path(__file__).resolve().parent;out=run/'college-region-metadata-01';out.mkdir(exist_ok=False)
mapped=json.loads((run/'native-type-initializer-map.json').read_bytes())['native_type_candidates'];entry=next(t for t in mapped if t['name']=='COLLEGEDATA_REGION')
college=next(t for t in json.loads((run/'affiliation-metadata-01/metadata.json').read_bytes()) if t['name']=='COLLEGEDATA');field=next(f for f in college['fields'] if f['name_crc']==zlib.crc32(b'UnlocalizedName'))
reader=None
try:
    reader=ReadOnlyGameProcess(int(sys.argv[1]));value=read_native_enum(reader,entry);words=field['words'];ptr=words[6]|words[7]<<32;dimension=reader.read(ptr,24,'COLLEGE_NAME_DIMENSION')
    if reader.read(ptr,24,'COLLEGE_NAME_DIMENSION_RECHECK')!=dimension:raise ValueError('college name dimension changed')
    reader.close();_json(out/'metadata.json',[value]);_json(out/'type_entries.json',[entry]);_json(out/'name-dimension.json',{'dimension_records_hex':dimension.hex(),'elements':int.from_bytes(dimension[:4],'little')})
    report={'status':'COLLEGE_REGION_AND_NAME_DIMENSION_CAPTURED','read_trace':reader.trace,'pid':int(sys.argv[1]),'game_writes':False,'player_value_reads':0}
except Exception as error:report={'status':'COLLEGE_REGION_METADATA_FAILED','error_type':type(error).__name__,'reason':str(error),'read_trace':reader.trace if reader else getattr(error,'read_trace',[]),'game_writes':False}
finally:
    if reader:reader.close()
_json(out/'report.json',report)
