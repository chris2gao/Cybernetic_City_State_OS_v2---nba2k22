"""Bounded native draft assets, prospect templates and waived-salary sources.

This observes source state; it never infers draft results, trades or free-agent
availability. Prospect/PLAYER public reads exclude the hidden Potential byte.
"""
from collections import Counter
from datetime import datetime,timezone
import hashlib,importlib.util,json,struct
from pathlib import Path
from engine import connect,ingest_capture
from schema_model import DOMAIN
from family_codec import decode_fixed_utf16,public_player_families
from live_reader import ReadOnlyGameProcess,ROSTER_RVA
from live_world import _public_raw,_json,read_binding,bound_database,_AcquisitionReceipt
from organization_reader import CORE_IDS,_ReadAdapter
from schedule_reader import bounded_block

DRAFT_PROFILE_PATH=DOMAIN/'config/draft_asset_profile.json'
DRAFT_PROFILE=json.loads(DRAFT_PROFILE_PATH.read_bytes())


def draft_codec():
    spec=importlib.util.spec_from_file_location('world_native_draft_assets',DOMAIN/'src/draft_assets.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def collect_market(reader):
    pointer=reader.read(reader.module_base+ROSTER_RVA,8,'MARKET_ROSTER_POINTER');root=int.from_bytes(pointer,'little')
    specs={1:(8192,1264),4:(4096,1264),8:(1024,4696),28:(10000,62),42:(4096,32),61:(4096,136)}
    descriptors={};tables={}
    for slot,(maximum,stride) in specs.items():
        raw=reader.read(root+slot*16,16,f'MARKET_SLOT{slot}_DESCRIPTOR');count,address=struct.unpack('<QQ',raw)
        if not 0<=count<=maximum or (count and address<0x10000):raise ValueError('market descriptor outside bounded envelope')
        descriptors[slot]=raw;tables[slot]={'count':count,'address':address,'stride':stride}
    teams=[];blobs={};controls=[]
    for i in range(tables[8]['count']):
        address=tables[8]['address']+i*4696;ident=reader.read(address+0xCA8,2,'MARKET_TEAM_NATIVE_ID')
        tid=int.from_bytes(ident,'little')
        if tid not in CORE_IDS:continue
        if any(t['native_team_id']==tid for t in teams):raise ValueError('duplicate core TEAM identity')
        name=reader.read(address+0x2B4,40,f'MARKET_TEAM:{tid}:NAME');city=reader.read(address+0x2E6,36,f'MARKET_TEAM:{tid}:CITY')
        stats_idx=reader.read(address+0xE80,2,f'MARKET_TEAM:{tid}:STATS_INDEX')
        teams.append({'native_team_id':tid,'address':address,'pool_index':i,'name':decode_fixed_utf16(name),
            'city':decode_fixed_utf16(city),'stats_index':int.from_bytes(stats_idx,'little')})
        for off,data,label in ((0xCA8,ident,'ID'),(0x2B4,name,'NAME'),(0x2E6,city,'CITY'),(0xE80,stats_idx,'STATS_INDEX')):
            controls.append((address+off,data,f'MARKET_TEAM:{tid}:{label}:RECHECK'))
    if {t['native_team_id'] for t in teams}!=CORE_IDS:raise ValueError('core TEAM set not complete')
    team_ids={t['address']:t['native_team_id'] for t in teams};first=teams[0];idx=first['stats_index']
    if idx>=tables[28]['count'] or idx==65535:raise ValueError('native season year source absent')
    current=reader.read(tables[28]['address']+idx*62,62,'MARKET_NATIVE_SEASON_CONTROL')
    year=1900+(current[4]&127);blobs['season-control.bin']=current
    controls.append((tables[28]['address']+idx*62,current,'MARKET_NATIVE_SEASON_RECHECK'))
    for i,item in enumerate(DRAFT_PROFILE['code_evidence']):
        raw=reader.read(reader.module_base+item['module_rva'],len(bytes.fromhex(item['expected_hex'])),f'MARKET_DRAFT_CODE:{i}')
        if raw.hex()!=item['expected_hex']:raise ValueError('draft native getter code changed: '+item['name'])
        blobs[f'draft-code-{i}.bin']=raw;controls.append((reader.module_base+item['module_rva'],raw,f'MARKET_DRAFT_CODE:{i}:RECHECK'))
    codec=draft_codec();observations,next_year=codec.read_assets(_ReadAdapter(reader),{'draft_assets':tables[42]},team_ids,year)
    assets=[]
    for index,row,raw in observations:
        meta=int.from_bytes(raw[28:32],'little')
        assets.append({'source_row_index':index,**row,'native_year_offset':meta&7,'native_round_code':(meta>>3)&31,
            'native_pick_index':(meta>>8)&255,'assigned_player_pointer_present':bool(int.from_bytes(raw[16:24],'little'))})
        blobs[f'draft-asset-{index}.bin']=raw;controls.append((tables[42]['address']+index*32,raw,f'MARKET_DRAFT_ASSET:{index}:RECHECK'))
    waived=[];players=tables[1]
    for index in range(tables[61]['count']):
        address=tables[61]['address']+index*136;raw=reader.read(address,136,f'MARKET_WAIVED:{index}')
        subject,owner=struct.unpack_from('<QQ',raw);player_index,rem=divmod(subject-players['address'],1264)
        row={'source_row_index':index,'native_team_id':team_ids.get(owner),'owner_mapping_status':'CORE_TEAM_POINTER' if owner in team_ids else 'UNMAPPED_OR_EMPTY',
            'native_player_id':None,'observed_player_name':None,'player_mapping_status':'SOURCE_POINTER_NOT_CURRENT_PLAYER_RECORD',
            'salary_year_1_raw':int.from_bytes(raw[16:20],'little'),'salary_year_2_raw':int.from_bytes(raw[20:24],'little'),
            'salary_year_3_raw':int.from_bytes(raw[24:28],'little')}
        if subject and not rem and 0<=player_index<players['count']:
            name=reader.read(subject,80,f'MARKET_WAIVED:{index}:PLAYER_NAME')
            ident=reader.read(subject+0x2F8,2,f'MARKET_WAIVED:{index}:PLAYER_ID')
            row.update(native_player_id=int.from_bytes(ident,'little'),player_mapping_status='CURRENT_PLAYER_POINTER_ONLY_NOT_CANONICAL_LINK')
            try:row['observed_player_name']=(decode_fixed_utf16(name[40:80])+' '+decode_fixed_utf16(name[:40])).strip()
            except UnicodeDecodeError:row['player_mapping_status']='INVALID_UTF16_NAME_PREFIX'
            blobs[f'waived-{index}.player-name.bin']=name;blobs[f'waived-{index}.player-id.bin']=ident
            controls.extend(((subject,name,f'MARKET_WAIVED:{index}:NAME_RECHECK'),(subject+0x2F8,ident,f'MARKET_WAIVED:{index}:ID_RECHECK')))
        waived.append(row);blobs[f'waived-{index}.bin']=raw;controls.append((address,raw,f'MARKET_WAIVED:{index}:RECHECK'))
    prospects=[];prospect_controls=[]
    for index in range(tables[4]['count']):
        address=tables[4]['address']+index*1264;raw=_public_raw(reader,address,f'MARKET_PROSPECT:{index}')
        row={'source_row_index':index,'native_prospect_id':int.from_bytes(raw[0x2F8:0x2FA],'little'),
            'draft_year':None,'class_year_status':'UNVERIFIED_NOT_INFERRED_FROM_FUTURE_PICK_BASE'}
        try:
            fields=public_player_families(raw);row['display_name']=(fields['vitals']['first_name']+' '+fields['vitals']['last_name']).strip()
            row['families']=fields;row['decode_status']='PUBLIC_REGISTERED_FIELDS_DECODED'
        except UnicodeDecodeError:
            row['display_name']=None;row['decode_status']='INVALID_UTF16_NAME_PREFIX_NO_PROFILE_INGEST'
        prospects.append(row);blobs[f'prospect-{index}.public.bin']=raw;prospect_controls.append((address,raw,index))
    for address,raw,label in controls:
        if bounded_block(reader,address,len(raw),label)!=raw:raise ValueError('market source changed during acquisition')
    for address,raw,index in prospect_controls:
        if _public_raw(reader,address,f'MARKET_PROSPECT:{index}:RECHECK')!=raw:raise ValueError('prospect source changed during acquisition')
    for slot,raw in descriptors.items():
        if reader.read(root+slot*16,16,f'MARKET_SLOT{slot}_RECHECK')!=raw:raise ValueError('market descriptor changed')
    if reader.read(reader.module_base+ROSTER_RVA,8,'MARKET_ROSTER_RECHECK')!=pointer:raise ValueError('market roster context changed')
    return {'descriptors':tables,'teams':teams,'season_year':year,'next_future_pick_year':next_year,'draft_assets':assets,
        'waived_salaries':waived,'prospects':prospects,'future_pick_count':sum(a['mapping_status']==codec.VERIFIED for a in assets),
        'prospect_id_duplicates':{str(k):v for k,v in Counter(p['native_prospect_id'] for p in prospects).items() if v>1},
        'game_writes':False,'potential_bytes_read':0,'source_scope':'DRAFT_FUTURE_PICKS; PROSPECT_TEMPLATES_YEAR_UNKNOWN; WAIVED_RAW_OBSERVATIONS'},blobs


def probe_market(pid,new_output_directory):
    out=Path(new_output_directory).resolve();out.mkdir(parents=True,exist_ok=False);reader=None
    report={'observed_at':datetime.now(timezone.utc).isoformat(),'pid':pid,'game_writes':False}
    try:
        reader=ReadOnlyGameProcess(pid);manifest,blobs=collect_market(reader);reader.close()
        for name,raw in blobs.items():(out/name).write_bytes(raw)
        _json(out/'market-manifest.json',manifest)
        report.update({'status':'MARKET_SOURCE_CAPTURED','read_trace':reader.trace,'artifact_sha256':{
            p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}})
    except Exception as error:
        report.update({'status':'MARKET_SOURCE_UNAVAILABLE','error_type':type(error).__name__,'reason':str(error),
            'read_trace':reader.trace if reader else getattr(error,'read_trace',[])})
    finally:
        if reader:reader.close()
    _json(out/'market-report.json',report);return report


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('pid',type=int);p.add_argument('new_output_directory');a=p.parse_args()
    r=probe_market(a.pid,a.new_output_directory);print(json.dumps({'status':r['status'],'reason':r.get('reason')}))
    raise SystemExit(0 if r['status']=='MARKET_SOURCE_CAPTURED' else 2)
