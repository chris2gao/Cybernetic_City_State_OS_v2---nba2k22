"""Named season/award type metadata and bounded RIP references in known game PE."""
import json,mmap,re,struct
from pathlib import Path
game=Path('E:/games/NBA 2K22/NBA2K22.exe')
with game.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    pe=struct.unpack_from('<I',data,0x3c)[0];count=struct.unpack_from('<H',data,pe+6)[0];opt=pe+24
    osize=struct.unpack_from('<H',data,pe+20)[0];base=struct.unpack_from('<Q',data,opt+24)[0];sections=[]
    for i in range(count):
        at=opt+osize+i*40;name=data[at:at+8].split(b'\0')[0].decode('ascii');vs,rva,size,offset=struct.unpack_from('<4I',data,at+8)
        sections.append((name,rva,size,offset))
    def to_rva(offset):
        for name,rva,size,off in sections:
            if off<=offset<off+size:return rva+offset-off
        raise ValueError('file position outside mapped sections')
    def to_off(rva):
        for name,start,size,off in sections:
            if start<=rva<start+size:return off+rva-start
        raise ValueError('RVA outside raw section')
    names=('COACHDATA','PLAYER_STATS','PLAYERSTATS','SEASON_STATS','AWARD_DATA','AWARD_MANAGER','AWARD','NEWS','LEAGUE_NEWS')
    records={};targets={}
    for name in names:
        needle=name.encode()+b'\0';start=0;hits=[]
        while len(hits)<16:
            at=data.find(needle,start)
            if at<0:break
            start=at+len(needle);rva=to_rva(at);hits.append(rva);targets[rva]=name
        full_names=[]
        for rva in hits:
            at=to_off(rva);begin=data.rfind(b'\0',max(0,at-96),at)+1
            full_names.append(data[begin:at+len(name)].decode('ascii',errors='replace'))
        records[name]={'string_rvas':hits,'full_string_candidates':full_names,'static_type_candidates':[],'rip_refs':[]}
        for rva in hits:
            pointer=struct.pack('<Q',base+rva);pos=0
            while True:
                ref=data.find(pointer,pos)
                if ref<0:break
                pos=ref+8
                if ref<40:continue
                h=struct.unpack_from('<8Q',data,ref-40)
                if not 0<h[0]<2000:continue
                try:
                    schema=struct.unpack_from('<10I',data,to_off(h[4]-base));fields=to_off(h[1]-base)
                    records[name]['static_type_candidates'].append({'type_rva':to_rva(ref-40),'count':h[0],'size':schema[5],'field_array_rva':h[1]-base})
                except ValueError:continue
    for sname,rva,size,off in sections:
        if sname!='.text':continue
        text=data[off:off+size]
        for m in re.finditer(rb'[\x48\x4c]\x8d[\x05\x0d\x15\x1d\x25\x2d\x35\x3d]....',text,re.DOTALL):
            address=rva+m.start();target=address+7+struct.unpack_from('<i',m.group(),3)[0]
            name=targets.get(target)
            if name and len(records[name]['rip_refs'])<12:
                records[name]['rip_refs'].append({'instruction_rva':address,'target_rva':target,
                    'context_rva':max(rva,address-64),'context_hex':text[max(0,m.start()-64):m.start()+128].hex()})
    try:known=to_off(80284224);known_header=data[known:known+64].hex()
    except ValueError:known_header='RUNTIME_SECTION_NO_STATIC_FILE_BYTES'
    result={'module_timestamp':struct.unpack_from('<I',data,pe+8)[0],'known_coach_header_hex':known_header,'types':records}
out=Path(__file__).parent/'awards-types-pe-inspection.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'module_timestamp':result['module_timestamp'],'known_coach_header_hex':result['known_coach_header_hex'],
 'types':{name:{'strings':v['string_rvas'],'full_names':v['full_string_candidates'],'static_types':v['static_type_candidates'],'rip_ref_count':len(v['rip_refs'])} for name,v in records.items()}}))
