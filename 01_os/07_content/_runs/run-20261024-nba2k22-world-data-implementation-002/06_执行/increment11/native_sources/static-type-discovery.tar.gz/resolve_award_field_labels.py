"""Match verified native CRCs to exact public PE identifier strings/candidates."""
import json,mmap,re,zlib
from pathlib import Path
root=Path(__file__).resolve().parents[5];runtime=Path(__file__).parent
metadata=json.loads((runtime/'award-metadata-03/award-native-metadata.json').read_bytes());wanted=set()
for t in metadata:
    wanted.update(f['name_crc'] for f in t['fields'])
    for e in t['enums'].values():wanted.update(v['name_crc'] for v in e['values'])
labels={c:set() for c in wanted}
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    for m in re.finditer(rb'(?<=\x00)[A-Za-z_][A-Za-z0-9_:]{0,95}\x00',data):
        raw=m.group()[:-1];crc=zlib.crc32(raw)
        if crc in labels:labels[crc].add(raw.decode('ascii'))
profile=json.loads((root/'08_Domain_Applications/Antigravity_GM_Engine/config/memory_field_profile.json').read_bytes())
names=[f['name'] for f in profile['fields']['PLAYER_STATS']]+['MVP','Mvp','MostValuablePlayer','AllNBA','AllNBATeam','AllDefensiveTeam','AllStarEast','AllStarWest','RookieOfTheYear','SixthMan','MostImprovedPlayer','Championship','Champion','DefensivePlayerOfTheYear','FinalsMVP','FinalsMvp']
for name in names:
    variants={name,name.upper(),name.title(),''.join(s.capitalize() for s in name.split('_')),name.replace('_','')}
    for variant in variants:
        crc=zlib.crc32(variant.encode())
        if crc in labels:labels[crc].add('CANDIDATE:'+variant)
for t in metadata:
    for f in t['fields']:f['matched_identifier_candidates']=sorted(labels[f['name_crc']])
    for e in t['enums'].values():
        for v in e['values']:v['matched_identifier_candidates']=sorted(labels[v['name_crc']])
out=runtime/'award-metadata-labeled.json';out.write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8',newline='\n')
stats=next(t for t in metadata if t['name']=='PLAYERSTATDATA')
print(json.dumps({'types':[{'name':t['name'],'size':t['struct_size'],'field_count':t['field_count'],
 'selected_fields':[{k:f[k] for k in ('offset','size','width','start_bit','matched_identifier_candidates','words')} for f in t['fields']
    if (t['name']=='PLAYERDATA' and any(x in label for label in f['matched_identifier_candidates'] for x in ('Stat','FirstName','LastName','UniqueId','Potential')))
    or (t['name']=='TEAMSTATDATA' and any('Year' in label for label in f['matched_identifier_candidates']))]} for t in metadata]}))
