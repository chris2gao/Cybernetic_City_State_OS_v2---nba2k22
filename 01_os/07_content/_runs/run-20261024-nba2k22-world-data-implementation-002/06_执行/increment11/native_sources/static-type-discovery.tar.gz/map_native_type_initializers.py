"""Map native type initializer arguments in the explicitly known game PE."""
import hashlib,json,mmap,re,struct
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_64,CS_OP_REG,CS_OP_MEM,CS_OP_IMM
game=Path('E:/games/NBA 2K22/NBA2K22.exe');md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
with game.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    pe=struct.unpack_from('<I',data,0x3c)[0];count=struct.unpack_from('<H',data,pe+6)[0];opt=pe+24;osize=struct.unpack_from('<H',data,pe+20)[0];sections=[]
    for i in range(count):
        at=opt+osize+i*40;name=data[at:at+8].split(b'\0')[0].decode('ascii');vs,rva,size,off=struct.unpack_from('<4I',data,at+8);sections.append((name,rva,size,off))
    def to_off(rva):
        for name,start,size,off in sections:
            if start<=rva<start+size:return off+rva-start
        raise ValueError('not in a file-backed section')
    found=[]
    for section,rva,size,off in sections:
        if section!='.text':continue
        raw=data[off:off+size]
        for match in re.finditer(rb'\x4c\x8d\x0d....',raw,re.DOTALL):
            address=rva+match.start();regs={};call=None;last=None
            for i in md.disasm(raw[match.start():match.start()+96],address):
                last=i
                if i.mnemonic=='lea' and len(i.operands)==2 and i.operands[0].type==CS_OP_REG and i.operands[1].type==CS_OP_MEM:
                    mem=i.operands[1].mem
                    if i.reg_name(mem.base)=='rip':regs[i.reg_name(i.operands[0].reg)]=i.address+i.size+mem.disp
                if i.mnemonic in ('call','jmp'):
                    if i.operands[0].type==CS_OP_IMM:call=i.operands[0].imm
                    break
                if i.mnemonic=='ret':break
            if call not in (0x1e53f30,0x1e53e90) or not all(k in regs for k in ('rcx','rdx','r8','r9')):continue
            try:
                name_off=to_off(regs['r9']);end=data.find(b'\0',name_off,name_off+128)
                if end<name_off:continue
                name=data[name_off:end].decode('ascii');schema_off=to_off(regs['r8']);schema=struct.unpack_from('<10I',data,schema_off)
                if not name or not re.fullmatch(r'[A-Za-z0-9_:<> ,*\[\]]+',name):continue
            except (ValueError,UnicodeDecodeError,struct.error):continue
            code=raw[match.start():match.start()+last.address+last.size-address]
            found.append({'name':name,'type_rva':regs['rcx'],'field_array_rva':regs['rdx'],'schema_rva':regs['r8'],
                'name_rva':regs['r9'],'static_auxiliary_word5_uninterpreted':schema[5],'initializer_rva':address,'constructor_rva':call,
                'initializer_hex':code.hex(),'initializer_sha256':hashlib.sha256(code).hexdigest()})
    result={'module_timestamp':struct.unpack_from('<I',data,pe+8)[0],'native_type_candidates':found,
        'status':'STATIC_INITIALIZER_ARGUMENTS_CURRENT_RUNTIME_HEADER_VALIDATION_REQUIRED'}
out=Path(__file__).parent/'native-type-initializer-map.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
selected=[x for x in found if any(word in x['name'].upper() for word in ('STAT','AWARD','NEWS','COACHDATA','RECORD'))]
print(json.dumps({'mapped_types':len(found),'selected_types':[{k:x[k] for k in ('name','type_rva','initializer_rva')} for x in selected if any(t in x['name'] for t in ('PLAYERSTATDATA','TEAMSTATDATA','AWARD','NEWS'))][:55]}))
