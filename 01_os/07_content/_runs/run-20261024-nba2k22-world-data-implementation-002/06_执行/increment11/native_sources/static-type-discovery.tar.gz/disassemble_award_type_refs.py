import json
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
p=Path(__file__).parent;source=json.loads((p/'awards-types-pe-inspection.json').read_bytes());md=Cs(CS_ARCH_X86,CS_MODE_64);result={}
for name in ('COACHDATA','AWARD_MANAGER','AWARD'):
    result[name]=[]
    for ref in source['types'][name]['rip_refs']:
        raw=bytes.fromhex(ref['context_hex']);start=ref['instruction_rva']-ref['context_rva']
        result[name].append([{'rva':hex(i.address),'instruction':i.mnemonic+' '+i.op_str} for i in md.disasm(raw[start:],ref['instruction_rva'])][:24])
(p/'award-type-ref-disassembly.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v[:1] for k,v in result.items()}))
