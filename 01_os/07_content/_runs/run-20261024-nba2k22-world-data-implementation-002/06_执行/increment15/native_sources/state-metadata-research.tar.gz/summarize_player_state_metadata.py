import json,mmap,re,zlib
from pathlib import Path
run=Path(__file__).resolve().parent;meta=json.loads((run/'player-state-metadata-01/metadata.json').read_bytes());wanted=set()
for t in meta:
    for f in t.get('fields',[]):wanted.update((f['name_crc'],f['words'][1]))
    wanted.update(v['name_crc'] for v in t.get('values',[]))
labels={c:set() for c in wanted}
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as file,mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ) as data:
    for m in re.finditer(rb'(?<=\x00)[A-Za-z_][A-Za-z0-9_:]{0,95}\x00',data):
        raw=m.group()[:-1];crc=zlib.crc32(raw)
        if crc in labels:labels[crc].add(raw.decode())
    for name in ('float','float32','Float','FLOAT','char','signed char','int8','uint8','int','unsigned int','unsigned char','short','unsigned short','double','Height','BirthYear','BirthMonth','BirthDay'):
        raw=name.encode();crc=zlib.crc32(raw)
        if crc in labels and data.find(raw+b'\0')>=0:labels[crc].add(name)
output=[]
for t in meta:
    if t['name']=='PLAYERDATA':
        fields=[{'names':sorted(labels[f['name_crc']]),'offset':f['offset'],'width':f['width'],'bit':f['start_bit'],'type_names':sorted(labels[f['words'][1]])} for f in t['fields'] if f['offset']<144]
        output.append({'type':t['name'],'early_fields':fields})
    elif 'fields' in t:
        output.append({'type':t['name'],'size':t['struct_size'],'fields':[{'names':sorted(labels[f['name_crc']]),'offset':f['offset'],'size':f['size'],'width':f['width'],'bit':f['start_bit'],'type_crc':f['words'][1],'type_names':sorted(labels[f['words'][1]])} for f in t['fields']]})
    else:output.append({'type':t['name'],'count':len(t['values']),'samples':[{'code':v['value'],'names':sorted(labels[v['name_crc']])} for v in t['values'][:9]]})
(run/'player-state-literal-labels.json').write_text(json.dumps({str(k):sorted(v) for k,v in labels.items()},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(output))
