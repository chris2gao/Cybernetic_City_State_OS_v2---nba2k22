"""Metadata-only source for vitals/injury/morale and pointed appearance type."""
from datetime import datetime,timezone
import hashlib,json,sys,zlib
from pathlib import Path
repo=Path.cwd();app=repo/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype';sys.path.insert(0,str(app))
from award_reader import read_native_fields
from league_reader import read_native_enum
from live_reader import ReadOnlyGameProcess
from live_world import _json
run=Path(__file__).resolve().parent;out=run/'player-state-metadata-01';out.mkdir(exist_ok=False)
mapped=json.loads((run/'native-type-initializer-map.json').read_bytes())['native_type_candidates']
old=next(t for t in json.loads((run/'player-detail-metadata-01/metadata.json').read_bytes()) if t['name']=='PLAYERDATA')
appearance=next(f for f in old['fields'] if f['name_crc']==zlib.crc32(b'Appearance'))
appearance_types=[t for t in mapped if zlib.crc32(t['name'].encode())==appearance['words'][1]]
if len(appearance_types)!=1:raise ValueError('appearance native type not unique')
entry_names={'PLAYERDATA','PLAYERDATA_INJURY','INJURY_STATUS','PLAYERDATA_MORALE_EVENT','PLAYERDATA_ORG_ROLE','PLAYERDATA_POSITION','PLAYERDATA_BESTHAND','PLAYERDATA_BESTDUNKHAND','SCHEDULEDATE'}
entries=[t for t in mapped if t['name'] in entry_names]+appearance_types
reader=None;report={'observed_at':datetime.now(timezone.utc).isoformat(),'pid':int(sys.argv[1]),'game_writes':False,'player_value_reads':0}
try:
    reader=ReadOnlyGameProcess(int(sys.argv[1]));values=[]
    for entry in entries:
        values.append(read_native_enum(reader,entry) if entry['constructor_rva']==0x1e53e90 else read_native_fields(reader,entry,read_enums=False))
    reader.close();_json(out/'metadata.json',values);_json(out/'type_entries.json',entries)
    report.update({'status':'PLAYER_STATE_METADATA_CAPTURED','read_trace':reader.trace,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}})
except Exception as error:report.update({'status':'PLAYER_STATE_METADATA_FAILED','error_type':type(error).__name__,'reason':str(error),'read_trace':reader.trace if reader else getattr(error,'read_trace',[])})
finally:
    if reader:reader.close()
_json(out/'report.json',report)
