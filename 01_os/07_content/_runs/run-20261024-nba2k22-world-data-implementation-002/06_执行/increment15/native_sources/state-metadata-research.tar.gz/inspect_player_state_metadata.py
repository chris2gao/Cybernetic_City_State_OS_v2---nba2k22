"""Locate vitals/health/morale descriptors in already captured native metadata."""
import hashlib,json,mmap,re,zlib
from pathlib import Path
run=Path(__file__).resolve().parent
metadata=json.loads((run/'player-detail-metadata-01/metadata.json').read_bytes());player=next(t for t in metadata if t['name']=='PLAYERDATA')
old=json.loads((run/'award-metadata-labeled.json').read_bytes());labels={f['name_crc']:set(f.get('matched_identifier_candidates',[])) for t in old for f in t['fields']}
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as file,mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ) as data:
    for m in re.finditer(rb'(?<=\x00)[A-Za-z_][A-Za-z0-9_:]{0,95}\x00',data):
        raw=m.group()[:-1];crc=zlib.crc32(raw)
        if crc in labels:labels[crc].add(raw.decode())
groups={'health':('injur','fatigue','energy','health','durab','wearandtear','recovery','outofshape','hurt','stamina'),
    'morale':('morale','emotion','satisfaction','role','happiness','complain','angry','desire','loyalty','playfor','financialsecurity'),
    'vitals':('weight','height','body','birth','age','college','country','position','hand','jersey','yearspro','nickname','appearance')}
selected={}
for group,words in groups.items():
    rows=[]
    for f in player['fields']:
        names=sorted(labels.get(f['name_crc'],[]))
        if any(word in name.lower() for name in names for word in words):rows.append({**f,'names':names})
    selected[group]=rows
mapped=json.loads((run/'native-type-initializer-map.json').read_bytes())['native_type_candidates']
by_rva={t['type_rva']:t for t in mapped}
related=[]
for f in [r for rows in selected.values() for r in rows]:
    if f['enum_pointer'] and f['enum_pointer']-0x140000000 in by_rva:
        t=by_rva[f['enum_pointer']-0x140000000];related.append({k:t[k] for k in ('name','type_rva','constructor_rva')})
result={'groups':selected,'related_types':list({t['name']:t for t in related}.values())}
(run/'player-state-metadata-inspection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'groups':{name:[{'names':f['names'],'offset':f['offset'],'size':f['size'],'width':f['width'],'bit':f['start_bit'],'type_crc':f['words'][1],'type_rva':f['enum_pointer']-0x140000000 if f['enum_pointer'] else None} for f in rows] for name,rows in selected.items()},'related_types':result['related_types']}))
