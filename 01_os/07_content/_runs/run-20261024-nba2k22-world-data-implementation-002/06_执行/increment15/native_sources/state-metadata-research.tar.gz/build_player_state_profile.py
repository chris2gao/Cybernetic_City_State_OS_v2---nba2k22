import hashlib,json,zlib
from pathlib import Path
run=Path(__file__).resolve().parent;app=Path.cwd()/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype'
meta=json.loads((run/'player-state-metadata-01/metadata.json').read_bytes());entries=json.loads((run/'player-state-metadata-01/type_entries.json').read_bytes())
labels=json.loads((run/'player-state-literal-labels.json').read_bytes());by_name={t['name']:t for t in meta};groups={}
requested={
 'vitals':{'Weight':'weight','BirthYear':'birth_year_raw','BirthMonth':'birth_month_raw','BirthDay':'birth_day_raw','Position':'primary_position_raw',
    'SecondaryPosition':'secondary_position_raw','TertiaryPosition':'tertiary_position_raw','BestHand':'best_hand_raw','BestDunkHand':'best_dunk_hand_raw',
    'JerseyNumber':'jersey_number_raw','YearsPro':'years_pro'},
 'health':{'InjuryType1':'injury1_type_raw','InjuryType2':'injury2_type_raw','OriginalInjuryType1':'original_injury1_type_raw','OriginalInjuryType2':'original_injury2_type_raw',
    'InjuryHealedPercentage1':'injury1_healed_percentage_raw','InjuryHealedPercentage2':'injury2_healed_percentage_raw','ProgressiveFatigue':'fatigue_raw','WearAndTear':'wear_and_tear_raw',
    'InjuryStartDate1':'injury1_start_date_word_raw','InjuryStartDate2':'injury2_start_date_word_raw','LatestInjuryHealedStartDate':'latest_healed_start_date_word_raw','LatestInjuryHealedDate':'latest_healed_date_word_raw',
    'InjuryDurationMinutes1':'injury1_duration_minutes_raw','InjuryDurationMinutes2':'injury2_duration_minutes_raw','InjuryStatus1':'injury1_status_raw','InjuryStatus2':'injury2_status_raw',
    'IsInjuryOnLeftBodyPart1':'injury1_left_side_raw','IsInjuryOnLeftBodyPart2':'injury2_left_side_raw','LatestInjurySlot':'latest_injury_slot_raw',
    'HadCareerEndedByInjury':'career_ended_by_injury_raw','ImportantInjuryRecovery':'important_injury_recovery_raw','HadImportantInjury':'had_important_injury_raw','NumGamesMissedDueToInjury':'games_missed_injury_raw'},
 'morale':{'Morale_Private':'morale','MoraleEventType':'morale_event_type_raw','MoraleEventAdjustment':'morale_event_adjustment_raw','OrgRole':'org_role_raw'},
 'appearance':{'HeightInTenthsOfMM':'height_raw','WingspanInTenthsOfMM':'wingspan_raw'}}
enums={t['name']:{str(v['value']):{'name_crc':v['name_crc'],'labels':labels[str(v['name_crc'])]} for v in t['values']} for t in meta if 'values' in t}
fields_by_type={name:{f['name_crc']:f for f in t['fields']} for name,t in by_name.items() if 'fields' in t}
for group,names in requested.items():
    t='APPEARANCEDATA' if group=='appearance' else 'PLAYERDATA';bound={}
    for native,column in names.items():
        f=fields_by_type[t][zlib.crc32(native.encode())];dtype=labels[str(f['words'][1])]
        if len(dtype)!=1:raise ValueError('primitive/native type name not unique: '+native)
        bound[column]={**f,'native_name':native,'native_type':dtype[0]}
        if t=='PLAYERDATA' and any(f['offset']<hi and lo<f['offset']+(f['start_bit']+f['width']+7)//8 for lo,hi in ((785,786),(880,882),(930,931),(1089,1090))):raise ValueError('private overlap: '+native)
    groups[group]=bound
for entry in entries:
    t=by_name[entry['name']]
    if 'fields' in t:
        signature=sorted((f['name_crc'],f['offset'],f['size'],f['format'],f['words'][5]) for f in t['fields'])
        entry.update({'expected_field_count':len(t['fields']),'field_signature_sha256':hashlib.sha256(json.dumps(signature,separators=(',',':')).encode()).hexdigest(),'expected_size':t['struct_size']})
output={'status':'CURRENT_RUNTIME_FIELD_NAMES_TYPES_ENUM_CODES_AND_SIGNATURES; UI_SCALING_AND_CONTEXT_SEPARATE','module_timestamp':1652287197,'types':entries,'groups':groups,'enum_labels':enums,
    'appearance_pointer':fields_by_type['PLAYERDATA'][zlib.crc32(b'Appearance')],
    'float_type_crc':zlib.crc32(b'float'),'signed_adjustment_type':groups['morale']['morale_event_adjustment_raw']['native_type']}
destination=app/'player_state_native_profile.json'
if destination.exists():raise FileExistsError('inspect an existing profile before replacing it')
destination.write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'group_counts':{k:len(v) for k,v in groups.items()},'float_type':groups['morale']['morale']['native_type'],
 'signed_adjustment_type':output['signed_adjustment_type'],'appearance_size':by_name['APPEARANCEDATA']['struct_size'],'enums':{k:len(v) for k,v in enums.items()}}))
