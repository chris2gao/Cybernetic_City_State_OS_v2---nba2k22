"""Bounded static getter candidates for known PLAYER badge bytes."""
import bisect,hashlib,json,mmap,re,struct
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
run=Path(__file__).resolve().parent;game=Path('E:/games/NBA 2K22/NBA2K22.exe');md=Cs(CS_ARCH_X86,CS_MODE_64)
with game.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    pe=struct.unpack_from('<I',data,0x3c)[0];n=struct.unpack_from('<H',data,pe+6)[0];optional=pe+24;osize=struct.unpack_from('<H',data,pe+20)[0];sections={}
    for i in range(n):
        at=optional+osize+40*i;name=data[at:at+8].split(b'\0')[0].decode();vs,rva,size,offset=struct.unpack_from('<4I',data,at+8);sections[name]=(rva,size,offset)
    rva,size,offset=sections['.pdata'];functions=[struct.unpack_from('<III',data,offset+i)[:2] for i in range(0,size-11,12)];starts=[a for a,b in functions]
    rva,size,offset=sections['.text'];text=data[offset:offset+size];hits=[];counts={}
    for byte in (1211,1219,1250):
        pattern=re.compile(rb'\x0f\xb6[\x80-\xbf]'+struct.pack('<I',byte));matches=list(pattern.finditer(text));counts[str(byte)]=len(matches)
        for match in matches:
            address=rva+match.start();j=bisect.bisect_right(starts,address)-1;bounds=functions[j] if j>=0 and address<functions[j][1] else None
            code=text[match.start():match.start()+96];instructions=[{'rva':i.address,'asm':i.mnemonic+' '+i.op_str} for i in md.disasm(code,address)]
            hits.append({'byte_offset':byte,'rva':address,'function':bounds,'instructions':instructions[:14],'code_hex':code.hex(),'sha256':hashlib.sha256(code).hexdigest()})
result={'status':'STATIC_GETTER_CANDIDATES_NOT_YET_SEMANTIC_CERTIFICATION','hits':hits,'match_counts':counts}
(run/'native-badge-getter-candidates.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
small=[h for h in hits if h['function'] and h['function'][1]-h['function'][0]<4096]
print(json.dumps({'match_counts':counts,'small_function_count':len({tuple(h['function']) for h in small}),
    'samples':[{'offset':h['byte_offset'],'rva':h['rva'],'function':h['function'],'instructions':h['instructions'][:9]} for h in small[:7]]}))
