import json
from pathlib import Path
run=Path(__file__).resolve().parent
types=json.loads((run/'award-metadata-04/award-native-metadata.json').read_bytes());p=next(t for t in types if t['name']=='PLAYERDATA')
labels=json.loads((run/'award-metadata-labeled.json').read_bytes());names={f['name_crc']:f['matched_identifier_candidates'] for t in labels for f in t['fields']}
profile=json.loads((Path.cwd()/'08_Domain_Applications/Antigravity_GM_Engine/config/memory_field_profile.json').read_bytes())
rows=[]
for d in profile['fields']['PLAYER']:
    if d['group']!='contract':continue
    start=d['offset']*8+d.get('start_bit',0)
    matches=[{'names':names.get(f['name_crc'],[]),'offset':f['offset'],'size':f['size'],'width':f['width'],'bit':f['start_bit'],'format':f['format'],'words':f['words']} for f in p['fields'] if f['offset']*8+f['start_bit']==start]
    rows.append({'registered':d['name'],'registered_bits':d['bits'],'matches':matches})
print(json.dumps({'contracts':rows,'salary_region':[{'names':names.get(f['name_crc'],[]),'offset':f['offset'],'size':f['size'],'width':f['width'],'words':f['words']} for f in p['fields'] if 416<=f['offset']<=444],
    'enum_candidates':[{'name':t['name'],'rva':t['type_rva']} for t in json.loads((run/'native-type-initializer-map.json').read_bytes())['native_type_candidates'] if t['constructor_rva']==0x1e53e90 and t['name'].startswith('PLAYERDATA_') and any(k in t['name'] for k in ('ROSTER','BADGE','CONTRACT'))]}))
