"""Inspect saved runtime metadata only; never acquire PLAYER values."""
import json
from pathlib import Path
root=Path.cwd();run=Path(__file__).resolve().parent
current=json.loads((run/'award-metadata-04/award-native-metadata.json').read_bytes())
labels=json.loads((run/'award-metadata-labeled.json').read_bytes())
names={f['name_crc']:f['matched_identifier_candidates'] for t in labels for f in t['fields']}
player=next(t for t in current if t['name']=='PLAYERDATA')
selected=[]
for f in player['fields']:
    matched=names.get(f['name_crc'],[])
    if any(word.lower() in label.lower() for label in matched for word in ('Badge','Contract','Salary','Extension','FreeAgent','Option','NoTrade','Bird','Sign','Loyal','Peak','Height','Weight','Birth')):
        selected.append({**f,'labels':matched})
profile=json.loads((root/'08_Domain_Applications/Antigravity_GM_Engine/config/memory_field_profile.json').read_bytes())
types=json.loads((run/'native-type-initializer-map.json').read_bytes())['native_type_candidates']
output={'runtime_selected_fields':selected,'registered_contract_fields':[f for f in profile['fields']['PLAYER'] if f['group']=='contract'],
    'related_native_types':[{k:t[k] for k in ('name','type_rva','initializer_rva','constructor_rva')} for t in types if any(s in t['name'].lower() for s in ('badge','contract','salary','freeagent'))]}
(run/'player-native-field-inspection.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8',newline='\n')
from collections import Counter
badge=[f for f in selected if any(s.endswith('Badge') for s in f['labels'])]
print(json.dumps({'field_count':len(selected),'badge_counts_by_width':dict(Counter(f['width'] for f in badge)),
    'badge_byte_range':[min(f['offset'] for f in badge),max(f['offset'] for f in badge)],
    'badge_samples':[{k:f[k] for k in ('labels','offset','width','start_bit')} for f in badge[:4]+badge[-4:]],
    'contract_window':[{'labels':names.get(f['name_crc'],[]),'offset':f['offset'],'size':f['size'],'width':f['width'],'bit':f['start_bit']} for f in player['fields'] if 780<=f['offset']<=870],
    'registered_contract_fields':output['registered_contract_fields'],
    'enum_types':[t for t in output['related_native_types'] if t['constructor_rva']==0x1e53e90 and not t['name'].startswith('AI_')]},ensure_ascii=False))
