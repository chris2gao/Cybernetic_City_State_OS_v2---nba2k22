"""Bind current field metadata to literal PE names and native enum codes."""
import hashlib,json,mmap,re,sys,zlib
from pathlib import Path
run=Path(__file__).resolve().parent;app=Path.cwd()/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype'
metadata=json.loads((run/'player-detail-metadata-01/metadata.json').read_bytes());entries=json.loads((run/'player-detail-metadata-01/type_entries.json').read_bytes())
player=next(t for t in metadata if t['name']=='PLAYERDATA');wanted={f['name_crc'] for f in player['fields']}
for t in metadata:
    if 'values' in t:wanted.update(v['name_crc'] for v in t['values'])
names={c:set() for c in wanted}
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    for match in re.finditer(rb'(?<=\x00)[A-Za-z_][A-Za-z0-9_:]{0,95}\x00',data):
        raw=match.group()[:-1];crc=zlib.crc32(raw)
        if crc in names:names[crc].add(raw.decode('ascii'))
    for value in ('Height','Weight','BirthYear','BirthMonth','BirthDay'):
        raw=value.encode();crc=zlib.crc32(raw)
        if crc in names and data.find(raw+b'\0')>=0:names[crc].add(value)
fields={next(iter(names[f['name_crc']])):f for f in player['fields'] if len(names[f['name_crc']])==1}
enums={}
for t in metadata:
    if 'values' not in t:continue
    labels={}
    for v in t['values']:
        candidates=sorted(names[v['name_crc']]);labels[str(v['value'])]={'name_crc':v['name_crc'],'labels':candidates}
        if len(candidates)!=1:raise RuntimeError('ambiguous enum literal: '+t['name']+':'+str(v['value']))
    enums[t['name']]=labels
definitions=json.loads((app.parent/'config/memory_field_profile.json').read_bytes())['fields']['PLAYER'];contracts={};comparison=[]
for d in definitions:
    if d['group']!='contract':continue
    start=d['offset']*8+d.get('start_bit',0)
    found=[(name,f) for name,f in fields.items() if f['offset']*8+f['start_bit']==start]
    if len(found)!=1:raise RuntimeError('contract literal/layout not unique: '+d['name'])
    native,f=found[0];contracts[d['name']]={**f,'native_name':native}
    comparison.append({'registered':d['name'],'native_name':native,'old_width':d['bits'],'native_width':f['width']})
normalize=lambda value:value.replace('_','').lower()
badge_enum=enums['PLAYERDATA_BADGE'];badges={}
for code,definition in badge_enum.items():
    label=definition['labels'][0];key=normalize(label)
    candidates=[(name,f) for name,f in fields.items() if name.endswith('Badge') and normalize(name[:-5])==key]
    if len(candidates)!=1:raise RuntimeError('badge enum/field binding not unique: '+label)
    name,f=candidates[0];badges[label]={**f,'native_name':name,'badge_id':int(code),'kind':'BOOLEAN' if f['width']==1 else 'LEVEL' if f['width']==3 else 'UNSUPPORTED',
        'reserved':label=='NONE'}
output={'status':'CURRENT_NATIVE_FIELDS_ENUMS_AND_LITERAL_CRCS; UI_AND_GETTER_MAPPING_SEPARATE','module_timestamp':1652287197,
    'types':entries,'contract_fields':contracts,'badge_fields':badges,'enum_labels':enums,
    'metadata_artifact_sha256':hashlib.sha256((run/'player-detail-metadata-01/metadata.json').read_bytes()).hexdigest(),
    'contract_width_comparison':comparison,'public_identity_fields':{name:fields[name] for name in ('UniqueId','PreservedId','CurrentTeam_Internal','UnlocalizedFirstName','UnlocalizedLastName')},
    'name_layout':'CURRENT_NATIVE UnlocalizedLastName +0 / UnlocalizedFirstName +40 uint16[20]; aligned UTF16 prefixes',
    'additional_vital_fields':{name:fields[name] for name in ('Height','Weight','BirthYear','BirthMonth','BirthDay') if name in fields}}
destination=app/'player_detail_native_profile.json'
if destination.exists() and '--update-with-dispatch' not in sys.argv:raise FileExistsError('never overwrite a profile without inspection')
if '--update-with-dispatch' in sys.argv:
    proof=json.loads((run/'badge-dispatch-proof.json').read_bytes())
    output['badge_base_dispatch']={k:proof[k] for k in ('code_start_rva','code_end_rva','code_hex','code_sha256','table_rva','table_hex','table_sha256','base_extraction_end_rva','verified_input_patterns')}
    output['badge_dispatch_proof_sha256']=hashlib.sha256((run/'badge-dispatch-proof.json').read_bytes()).hexdigest()
    output['status']='CURRENT_NATIVE_FIELDS_ENUMS_LITERAL_CRCS_AND_ALL_BASE_BADGE_DISPATCH_CASES_VERIFIED; EFFECTIVE_CONTEXT_AND_UI_SEPARATE'
destination.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'enums':{name:labels for name,labels in enums.items() if name!='PLAYERDATA_BADGE'},'badge_fields':len(badges),
    'badge_id_sample':list(badges)[:5],'width_corrections':[r for r in comparison if r['old_width']!=r['native_width']],
    'vital_fields':list(output['additional_vital_fields']),'inline_name_metadata':[{'labels':sorted(names[f['name_crc']]),'offset':f['offset'],'size':f['size'],'width':f['width']} for f in player['fields'] if f['offset'] in (0,40)]}))
