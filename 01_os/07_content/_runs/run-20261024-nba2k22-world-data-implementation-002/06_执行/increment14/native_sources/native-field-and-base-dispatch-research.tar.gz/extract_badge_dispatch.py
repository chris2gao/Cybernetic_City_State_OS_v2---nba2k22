import hashlib,json,mmap,struct
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
run=Path(__file__).resolve().parent;start,end=9943159,9944621;md=Cs(CS_ARCH_X86,CS_MODE_64)
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    pe=struct.unpack_from('<I',data,0x3c)[0];n=struct.unpack_from('<H',data,pe+6)[0];at=pe+24+struct.unpack_from('<H',data,pe+20)[0]
    for i in range(n):
        vs,rva,size,offset=struct.unpack_from('<4I',data,at+i*40+8)
        if rva<=start and end<=rva+size:raw=bytes(data[offset+start-rva:offset+end-rva]);break
instructions=[{'rva':i.address,'asm':i.mnemonic+' '+i.op_str} for i in md.disasm(raw,start)]
out={'status':'STATIC_BADGE_DISPATCH_CANDIDATE; CONTROL_FLOW_AND_RUNTIME_BYTES_REQUIRE_VALIDATION','start_rva':start,'end_rva':end,'code_hex':raw.hex(),
    'code_sha256':hashlib.sha256(raw).hexdigest(),'instructions':instructions}
(run/'badge-dispatch-function.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'first':instructions[:22],'last':instructions[-24:]}))
