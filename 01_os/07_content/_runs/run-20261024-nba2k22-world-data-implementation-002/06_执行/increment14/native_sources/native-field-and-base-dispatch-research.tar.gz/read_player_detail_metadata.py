"""Read native type metadata only; never acquire PLAYER field values."""
from datetime import datetime,timezone
import hashlib,json,sys
from pathlib import Path
repo=Path.cwd();app=repo/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype';sys.path.insert(0,str(app))
from award_reader import read_native_fields
from league_reader import read_native_enum
from live_reader import ReadOnlyGameProcess
from live_world import _json
run=Path(__file__).resolve().parent;out=run/'player-detail-metadata-01';out.mkdir(exist_ok=False)
mapped=json.loads((run/'native-type-initializer-map.json').read_bytes());by_rva={t['type_rva']:t for t in mapped['native_type_candidates']}
player=next(t for t in json.loads((app/'award_native_profile.json').read_bytes())['types'] if t['name']=='PLAYERDATA')
old=next(t for t in json.loads((run/'award-metadata-04/award-native-metadata.json').read_bytes()) if t['name']=='PLAYERDATA')
labels=json.loads((run/'award-metadata-labeled.json').read_bytes());names={f['name_crc']:f['matched_identifier_candidates'] for t in labels for f in t['fields']}
roster=next(f for f in old['fields'] if names.get(f['name_crc'])==['RosterType'])
entries=[player]+[t for t in mapped['native_type_candidates'] if t['name'] in ('PLAYERDATA_BADGE_LEVEL','PLAYERDATA_BADGE','PLAYERDATA_CONTRACT_OPTION')]+[by_rva[roster['enum_pointer']-0x140000000]]
reader=None;report={'observed_at':datetime.now(timezone.utc).isoformat(),'pid':int(sys.argv[1]),'game_writes':False,'player_value_reads':0}
try:
    reader=ReadOnlyGameProcess(int(sys.argv[1]));values=[]
    for entry in entries:
        values.append(read_native_fields(reader,entry,1264,read_enums=False) if entry['name']=='PLAYERDATA' else read_native_enum(reader,entry))
    reader.close();_json(out/'metadata.json',values);_json(out/'type_entries.json',entries)
    report.update({'status':'PLAYER_DETAIL_METADATA_CAPTURED','read_trace':reader.trace,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}})
except Exception as error:
    report.update({'status':'PLAYER_DETAIL_METADATA_FAILED','reason':str(error),'error_type':type(error).__name__,'read_trace':reader.trace if reader else getattr(error,'read_trace',[])})
finally:
    if reader:reader.close()
_json(out/'report.json',report)
