"""Validate all native ID->base-bit dispatch cases without executing game code."""
import hashlib,json,mmap,re,struct
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
run=Path(__file__).resolve().parent;app=Path.cwd()/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype'
profile=json.loads((app/'player_detail_native_profile.json').read_bytes());start,end,table=0x97b840,0x97bee0,0x97bee0;boundary=0x97be1e
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    pe=struct.unpack_from('<I',data,0x3c)[0];n=struct.unpack_from('<H',data,pe+6)[0];at=pe+24+struct.unpack_from('<H',data,pe+20)[0];sections=[]
    for i in range(n):
        vs,rva,size,offset=struct.unpack_from('<4I',data,at+i*40+8);sections.append((rva,size,offset))
    def read(rva,length):
        for base,size,offset in sections:
            if base<=rva and rva+length<=base+size:return bytes(data[offset+rva-base:offset+rva-base+length])
        raise ValueError('outside backed section')
    code=read(start,end-start);jump=read(table,99*4)
instructions={i.address:(i.mnemonic,i.op_str,i.size) for i in Cs(CS_ARCH_X86,CS_MODE_64).disasm(code,start)}
bindings={v['badge_id']:(name,v) for name,v in profile['badge_fields'].items()};proof=[]
for badge_id,target in enumerate(struct.unpack('<99I',jump)):
    name,binding=bindings[badge_id];paths=set()
    for byte in range(256):
        pc=target;value=0;edi=0;reads=[];path=[]
        for step in range(16):
            if pc==boundary:break
            mnemonic,operands,length=instructions[pc];path.append(pc)
            if mnemonic=='movzx' and operands.startswith('ebx, byte ptr [rcx + '):
                offset=int(re.search(r'\+ (0x[0-9a-f]+)',operands).group(1),16);reads.append(offset);value=byte
            elif mnemonic=='mov' and operands=='edi, 1':edi=1
            elif mnemonic=='shr' and operands.startswith('bl, '):value>>=int(operands.split(', ')[1],0)
            elif mnemonic=='and' and operands.startswith('bl, '):
                mask=operands.split(', ')[1];value&=edi if mask=='dil' else int(mask,0)
            elif mnemonic=='jmp':pc=int(operands,0);continue
            else:raise ValueError('unhandled dispatch instruction: '+mnemonic+' '+operands)
            pc+=length
        else:raise ValueError('dispatch path exceeds bound')
        assert reads==[binding['offset']] and value==(byte>>binding['start_bit'])&((1<<binding['width'])-1),(name,byte,reads,value)
        paths.add(tuple(path))
    assert len(paths)==1
    proof.append({'badge_id':badge_id,'badge_label':name,'case_rva':target,'instruction_rvas':list(next(iter(paths))),
        'offset':binding['offset'],'start_bit':binding['start_bit'],'width':binding['width'],'all_256_byte_patterns_match':True})
result={'status':'ALL_99_ID_TO_BASE_BADGE_BIT_DISPATCH_CASES_VERIFIED_STATIC; NO_CODE_EXECUTION',
    'code_start_rva':start,'code_end_rva':end,'code_hex':code.hex(),'code_sha256':hashlib.sha256(code).hexdigest(),
    'table_rva':table,'table_hex':jump.hex(),'table_sha256':hashlib.sha256(jump).hexdigest(),'base_extraction_end_rva':boundary,
    'verified_input_patterns':99*256,'cases':proof,
    'post_extraction_instructions':[{'rva':pc,'asm':m+' '+o} for pc,(m,o,size) in instructions.items() if pc>=boundary],
    'limit':'Only stored base badge extraction is certified. Later context/boost logic and UI/effective-level semantics are not promoted.'}
(run/'badge-dispatch-proof.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'status':result['status'],'patterns':99*256,'post_extraction':result['post_extraction_instructions'][:20]}))
