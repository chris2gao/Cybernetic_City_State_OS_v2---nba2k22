import hashlib,json,mmap,re,zlib
from pathlib import Path
r=Path(__file__).resolve().parent;app=Path.cwd()/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype';inspection=json.loads((r/'public-skill-metadata-inspection.json').read_bytes())
metadata=json.loads((r/'skill-metadata-01/metadata.json').read_bytes());entries=json.loads((r/'skill-metadata-01/type_entries.json').read_bytes());by_name={t['name']:t for t in metadata};fields={f['name_crc']:f for f in by_name['PLAYERDATA']['fields']}
names={f['name_crc']:f['literal_names'][0] for f in inspection['fields'] if len(f['literal_names'])==1};labels={};wanted={v['name_crc'] for v in by_name['PLAYERDATA_PLAYTYPE']['values']}
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    for match in re.finditer(rb'(?<=\x00)[A-Za-z_][A-Za-z0-9_:]{0,95}\x00',data):
        raw=match.group()[:-1];crc=zlib.crc32(raw)
        if crc in wanted:labels.setdefault(str(crc),set()).add(raw.decode())
def snake(name):return re.sub(r'(?<!^)(?=[A-Z])','_',name).lower()
def bound(field):return {**field,'native_name':names[field['name_crc']]}
attrs={}
for item in inspection['attributes']:
    candidates=item['native_candidates'];assert len(candidates)==1
    name=item['registered']['name'];column=('three_point_shot' if name=='3pt_shot' else name)+'_raw';attrs[column]=bound(fields[candidates[0]['name_crc']])
for native,column in [('EmotionAbilityRaw','emotion_raw'),('ReactionTimeAbilityRaw','reaction_time_raw')]:attrs[column]=bound(fields[zlib.crc32(native.encode())])
registered={v['offset']:v['registered_name'].lower()+'_raw' for v in inspection['tendencies']};tendencies={}
for f in fields.values():
    native=names[f['name_crc']]
    if not native.startswith('Previous') and native.endswith('TendencyRaw'):
        assert 1112<=f['offset']<1211 and f['width']==8 and f['start_bit']==0
        column=registered.get(f['offset'],snake(native));assert column not in tendencies;tendencies[column]=bound(f)
assert len(attrs)==56 and len(tendencies)==99 and {f['offset'] for f in tendencies.values()}==set(range(1112,1211))
play={str(i):bound(fields[zlib.crc32(('PlayType'+str(i+1)).encode())]) for i in range(4)}
enums={str(v['value']):{'name_crc':v['name_crc'],'labels':sorted(labels.get(str(v['name_crc']),[]))} for v in by_name['PLAYERDATA_PLAYTYPE']['values']}
assert all(len(v['labels'])==1 for v in enums.values())
for e in entries:
    if e['name']=='PLAYERDATA':
        t=by_name[e['name']];sig=sorted((f['name_crc'],f['offset'],f['size'],f['format'],f['words'][5]) for f in t['fields']);e.update({'expected_size':t['struct_size'],'expected_field_count':len(t['fields']),'field_signature_sha256':hashlib.sha256(json.dumps(sig,separators=(',',':')).encode()).hexdigest()})
profile={'status':'CURRENT_NATIVE_SKILL_FIELD_SIGNATURES_AND_PLAYTYPE_ENUM; RAW_STORAGE_NOT_UI_ACCEPTANCE','module_timestamp':1652287197,'types':entries,'attributes':attrs,'tendencies':tendencies,'play_types':play,'initiator':bound(fields[zlib.crc32(b'IsPlayInitiator')]),'play_type_enum':enums,'unacquired_fields':['PotentialRaw','PreviousPotentialRaw','MinPotential','MaxPotential','OriginalPotential','CachedOverall_NeverCall','PreviousOverallAbility'],'overall_status':'CURRENT_OVERALL_GETTER_AND_CACHE_VALIDITY_SEMANTICS_NOT_ESTABLISHED'}
out=app/'player_skill_native_profile.json';assert not out.exists();out.write_text(json.dumps(profile,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'attributes':len(attrs),'tendencies':len(tendencies),'play_type_enum':enums}))
