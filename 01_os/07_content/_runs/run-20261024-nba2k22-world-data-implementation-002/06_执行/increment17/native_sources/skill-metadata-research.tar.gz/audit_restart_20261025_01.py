"""Fresh process/build/pool audit after Human gameplay and restart; no fact ingest."""
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,struct,sys
from pathlib import Path
repo=Path.cwd();app=repo/'08_Domain_Applications/Antigravity_GM_Engine/world_data_prototype';sys.path.insert(0,str(app))
from live_reader import ReadOnlyGameProcess,ROSTER_RVA,SEASON_RVA,GAME_OFFSET
from live_world import _json,read_binding,bound_database
from player_detail_reader import collect_public_player_pool,verify_detail_metadata
from player_state_reader import verify_state_metadata
from player_affiliation_reader import verify_affiliation_metadata
from player_skill_reader import verify_skill_metadata
from schedule_reader import bounded_block
from readers import _module
from engine import connect
r=Path(__file__).resolve().parent;out=r/'restart-audit-20261025-01';out.mkdir(exist_ok=False);reader=None
report={'observed_at':datetime.now(timezone.utc).isoformat(),'pid':int(sys.argv[1]),'game_writes':False,'database_ingest':False}
try:
    binding,binding_hash=read_binding(r/'world-saves/nba2k22_test_01','MyLEAGUE0003');db=bound_database(r/'world-saves/nba2k22_test_01',binding);before=hashlib.sha256(db.read_bytes()).hexdigest()
    reader=ReadOnlyGameProcess(int(sys.argv[1]));dos=reader.read(reader.module_base,64,'RESTART_DOS_HEADER');assert dos[:2]==b'MZ';peoff=int.from_bytes(dos[60:64],'little');assert 64<=peoff<4096
    pe=reader.read(reader.module_base+peoff,24,'RESTART_PE_HEADER');assert pe[:4]==b'PE\0\0';timestamp=int.from_bytes(pe[8:12],'little');assert timestamp==1652287197
    metadata=[]
    for verify in (verify_skill_metadata,verify_detail_metadata,verify_state_metadata,verify_affiliation_metadata):metadata.extend(verify(reader))
    m,blobs=collect_public_player_pool(reader,ranges=[(0,80),(96,104),(244,246),(760,764)],metadata=metadata)
    pointer=reader.read(reader.module_base+ROSTER_RVA,8,'RESTART_FRESH_ROOT');root=int.from_bytes(pointer,'little');controls=[(reader.module_base+ROSTER_RVA,pointer)];descriptors={}
    for slot,stride,maximum in ((1,1264,8192),(8,4696,1024),(10,32,1232),(24,48,65535),(28,62,10000)):
        raw=reader.read(root+slot*16,16,'RESTART_DESCRIPTOR:'+str(slot));count,address=struct.unpack('<QQ',raw)
        assert 1<=count<=maximum and address>=0x10000;descriptors[str(slot)]={'count':count,'address':address,'stride':stride};controls.append((root+slot*16,raw))
    assert descriptors['1']==m['descriptors'][1] and descriptors['8']==m['descriptors'][8]
    season_pointer=reader.read(reader.module_base+SEASON_RVA,8,'RESTART_FRESH_SEASON');season=int.from_bytes(season_pointer,'little');controls.append((reader.module_base+SEASON_RVA,season_pointer));count=descriptors['10']['count']
    schedule=bounded_block(reader,season+GAME_OFFSET,count*60,'RESTART_SCHEDULE_HEADERS');decoder=_module('boxscore_decoder').BoxScoreDecoder;games=[]
    for i in range(count):
        game=decoder.decode_game_header(schedule[i*60:(i+1)*60]);assert game['status'] in (0,1,2) and game['home_team_id']!=game['away_team_id'];games.append({'pool_index':i,'native_game_id':game['game_id'],'status':game['status']})
    assert len({g['native_game_id'] for g in games})==count
    assert bounded_block(reader,season+GAME_OFFSET,count*60,'RESTART_SCHEDULE_HEADERS_RECHECK')==schedule
    for address,raw in controls:assert reader.read(address,len(raw),'RESTART_CONTEXT_RECHECK')==raw
    reader.close();old_path=r/'player-affiliation-live-v15/affiliation-manifest.json';old=json.loads(old_path.read_bytes());old_result=json.loads((r/'player-affiliation-live-v15/ingest-result.json').read_bytes());before_sources={p['source_player_index']:p for p in old['players']}
    changed=[p['source_player_index'] for p in m['players'] if before_sources.get(p['source_player_index'])!=p]
    old_schedule=json.loads((r/'season-capture-01/schedule-manifest.json').read_bytes()) if (r/'season-capture-01/schedule-manifest.json').exists() else None
    _json(out/'public-identity-manifest.json',m);_json(out/'schedule-statuses.json',games)
    assert hashlib.sha256(db.read_bytes()).hexdigest()==before
    with connect(db,True) as c:
        schema=c.execute('PRAGMA user_version').fetchone()[0];units=c.execute('SELECT count(*) FROM capture_units').fetchone()[0];assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok' and not c.execute('PRAGMA foreign_key_check').fetchall()
    report.update({'status':'FRESH_RESTART_CONTEXT_AND_ACTIVE_READERS_VERIFIED','module_base':hex(reader.module_base),'module_size':reader.module_size,'module_timestamp':timestamp,'season_year':m['season_year'],
        'save_id':binding['save_id'],'native_save_filename':binding['native_save_filename'],'save_binding_basis':binding['identity_basis'],'binding_sha256':binding_hash,
        'fresh_descriptors':descriptors,'pool_addresses_changed':{slot:old['descriptors'][slot]['address']!=descriptors[slot]['address'] for slot in ('1','8')},
        'public_subject_count':len(m['players']),'current_core_roster_count':m['current_core_roster_count'],'changed_public_identity_or_roster_rows_since_increment16':len(changed),
        'changed_source_indices':changed,'schedule_status_counts':dict(Counter(str(g['status']) for g in games)),
        'verified_profile_groups':['skills','contracts_and_base_badges','vitals_health_morale','affiliation_college'],
        'fact_database_schema_version':schema,'fact_database_units':units,'fact_database_sha256_before_and_after':before,'database_unchanged':True,
        'old_dynamic_addresses_reused':False,'all_acquisitions_reopen_process_and_resolve_roots':True,'gameplay_changes_are_new_observations_not_retroactive_source_rewrites':True,
        'read_trace':reader.trace,'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}})
except Exception as error:report.update({'status':'FRESH_RESTART_AUDIT_FAILED','error_type':type(error).__name__,'reason':str(error),'read_trace':reader.trace if reader else getattr(error,'read_trace',[])})
finally:
    if reader:reader.close()
_json(out/'report.json',report)
