import json
from pathlib import Path
r=Path(__file__).resolve().parent;m=json.loads((r/'public-skill-metadata-inspection.json').read_bytes());mapped=json.loads((r/'native-type-initializer-map.json').read_bytes())['native_type_candidates']
for kind,selected in [('additional_abilities',[f for f in m['fields'] if f['offset'] in (1106,1111)]),('play_types',[f for f in m['fields'] if any('PlayType' in s or 'Initiator' in s for s in f['literal_names'])])]:
    print(kind,json.dumps([{k:f[k] for k in ('literal_names','offset','start_bit','width','enum_pointer','words')} if kind=='play_types' else {k:f[k] for k in ('literal_names','offset','start_bit','width')} for f in selected]))
print('enum_type',json.dumps(next(t for t in mapped if t['name']=='PLAYERDATA_PLAYTYPE')))
current=[f for f in m['fields'] if 1112<=f['offset']<1211];print('current_tendencies',len(current),'unregistered',json.dumps([f['literal_names'][0] for f in current if f['offset'] not in {t['offset'] for t in m['tendencies']}]))
