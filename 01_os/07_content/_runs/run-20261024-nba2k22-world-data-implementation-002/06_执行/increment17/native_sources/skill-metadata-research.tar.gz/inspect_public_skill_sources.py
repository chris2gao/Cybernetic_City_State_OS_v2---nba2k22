import json,mmap,re,zlib
from pathlib import Path
r=Path(__file__).resolve().parent;domain=Path.cwd()/'08_Domain_Applications/Antigravity_GM_Engine';app=domain/'world_data_prototype'
metadata=json.loads((r/'affiliation-metadata-01/metadata.json').read_bytes());player=next(t for t in metadata if t['name']=='PLAYERDATA');wanted={f['name_crc'] for f in player['fields']};labels={}
with Path('E:/games/NBA 2K22/NBA2K22.exe').open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    for match in re.finditer(rb'(?<=\x00)[A-Za-z_][A-Za-z0-9_:]{0,95}\x00',data):
        raw=match.group()[:-1];crc=zlib.crc32(raw)
        if crc in wanted:labels.setdefault(str(crc),set()).add(raw.decode())
labels={crc:sorted(names) for crc,names in labels.items()};fields=[{**f,'literal_names':labels.get(str(f['name_crc']),[])} for f in player['fields']]
profile=json.loads((domain/'config/memory_field_profile.json').read_bytes());config=json.loads((domain/'config/state_io_native/player.json').read_bytes())
attrs=[f for f in profile['fields']['PLAYER'] if f['group']=='attributes' and f['name']!='potential'];tendencies=config['TENDENCY_OFFSETS']
result={'player_field_count':len(fields),'literal_name_count':len(labels),'fields':fields,'attributes':[], 'tendencies':[]}
for f in attrs:result['attributes'].append({'registered':f,'native_candidates':[n for n in fields if n['offset']==f['offset']]})
for name,offset in tendencies.items():result['tendencies'].append({'registered_name':name,'offset':offset,'native_candidates':[n for n in fields if n['offset']==offset]})
(r/'public-skill-metadata-inspection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'native_fields':len(fields),'named_fields':len(labels),'registered_attributes':len(attrs),'registered_tendencies':len(tendencies)}))
for family in ('attributes','tendencies'):
    for v in result[family]:
        print(family,json.dumps({'registered':v.get('registered_name',v.get('registered',{}).get('name')),'fields':[{k:n[k] for k in ('literal_names','offset','start_bit','width')} for n in v['native_candidates']]}))
for f in fields:
    if any('PlayType' in name or 'Overall' in name for name in f['literal_names']):print('extra',json.dumps({k:f[k] for k in ('literal_names','offset','start_bit','width')}))
